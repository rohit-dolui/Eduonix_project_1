const words=['hello', 'world', 'this', 'is', 'javascript'];

const finalwords=words.map(capitalize);

function capitalize(str){
    let spl = str.split(' ');
    for(let i = 0; i < spl.length; i++){
      let temp = spl[i];
      temp = temp[0].toUpperCase() + temp.slice(1)
      temp = temp.slice(0,-1) + temp[temp.length - 1].toUpperCase();
      spl[i] = temp;
    }
    return spl.join(' ');
  }

  console.log(finalwords);
