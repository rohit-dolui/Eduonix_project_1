Snippet 1:

let string = 'hello';

string = string + 'world';

console.log(string);


Snippet 2: 

const time = new Date();
function setTime() {

console.log(time)

}

setTime();

